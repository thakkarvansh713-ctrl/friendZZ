package com.friendsmod;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import net.minecraft.client.Minecraft;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.WebSocket;
import java.nio.ByteBuffer;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.CopyOnWriteArrayList;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.Function;

/** Connection to the companion server: presence, friends, messages and the world tunnel. */
public final class Net {
	public static Net I;

	public record Friend(String name, String status) {}

	public record Msg(boolean mine, String text) {}

	/** Bumped on every change; screens compare it to know when to redraw. */
	public final AtomicInteger version = new AtomicInteger();
	public volatile boolean connected;
	public volatile String info = "";
	public volatile String viewing; // friend whose chat is open
	public volatile int hostPort = -1; // my LAN port while my world is open to friends
	public volatile List<Friend> friends = List.of();
	public volatile List<String> requests = List.of();
	public final Map<String, List<Msg>> chats = new ConcurrentHashMap<>();
	public final Map<String, Integer> unread = new ConcurrentHashMap<>();

	private static final HttpClient HTTP = HttpClient.newHttpClient();
	private volatile WebSocket ws;
	private volatile boolean connecting;
	private final Map<Integer, Socket> socks = new ConcurrentHashMap<>();
	private CompletableFuture<Void> chain = CompletableFuture.completedFuture(null);

	// ---- lifecycle ----

	public void start() {
		friends = offlineFriends();
		Thread t = new Thread(() -> {
			while (true) {
				if (ws == null && !connecting) connect();
				try {
					Thread.sleep(5000);
				} catch (InterruptedException e) {
					return;
				}
			}
		}, "friendsmod-net");
		t.setDaemon(true);
		t.start();
	}

	private void connect() {
		connecting = true;
		try {
			HTTP.newWebSocketBuilder().buildAsync(URI.create(Config.I.server), new Listener())
				.whenComplete((w, e) -> {
					connecting = false;
					if (e != null) down(null);
				});
		} catch (Exception e) {
			connecting = false;
			info = "Bad server address in Settings";
			version.incrementAndGet();
		}
	}

	public void reconnect() {
		WebSocket w = ws;
		if (w != null) w.abort();
		down(w);
	}

	private void down(WebSocket w) {
		if (w == null || ws == w) ws = null;
		connected = false;
		friends = offlineFriends();
		requests = List.of();
		socks.keySet().forEach(id -> closeSock(id, false));
		version.incrementAndGet();
	}

	private final class Listener implements WebSocket.Listener {
		private final StringBuilder text = new StringBuilder();
		private final ByteArrayOutputStream bin = new ByteArrayOutputStream();

		@Override
		public void onOpen(WebSocket w) {
			ws = w;
			String name = Minecraft.getInstance().getUser().getName();
			JsonObject auth = o("auth", "name", name, "token", Config.I.token, "hidden", Config.I.appearOffline);
			auth.add("friends", friendsJson());
			send(auth);
			w.request(1);
		}

		@Override
		public CompletionStage<?> onText(WebSocket w, CharSequence d, boolean last) {
			text.append(d);
			if (last) {
				String s = text.toString();
				text.setLength(0);
				try {
					onMsg(JsonParser.parseString(s).getAsJsonObject());
				} catch (Exception ignored) {
				}
			}
			w.request(1);
			return null;
		}

		@Override
		public CompletionStage<?> onBinary(WebSocket w, ByteBuffer d, boolean last) {
			byte[] a = new byte[d.remaining()];
			d.get(a);
			bin.write(a, 0, a.length);
			if (last) {
				byte[] f = bin.toByteArray();
				bin.reset();
				fromNet(f);
			}
			w.request(1);
			return null;
		}

		@Override
		public CompletionStage<?> onClose(WebSocket w, int code, String reason) {
			down(w);
			return null;
		}

		@Override
		public void onError(WebSocket w, Throwable t) {
			down(w);
		}
	}

	// ---- incoming ----

	private static String s(JsonObject m, String k) {
		return m.has(k) ? m.get(k).getAsString() : "";
	}

	private void onMsg(JsonObject m) {
		switch (s(m, "t")) {
			case "ok" -> {
				connected = true;
				info = "";
				if (hostPort > 0) send(o("host", "on", true));
			}
			case "err", "info" -> info = s(m, "text");
			case "state" -> {
				List<Friend> f = new ArrayList<>();
				for (JsonElement e : m.getAsJsonArray("friends")) {
					JsonObject x = e.getAsJsonObject();
					f.add(new Friend(s(x, "name"), s(x, "status")));
				}
				friends = f;
				List<String> r = new ArrayList<>();
				for (JsonElement e : m.getAsJsonArray("requests")) if (!has(Config.I.ignored, e.getAsString())) r.add(e.getAsString());
				requests = r;
			}
			case "msg" -> {
				String from = s(m, "from");
				chats.computeIfAbsent(from, k -> new CopyOnWriteArrayList<>()).add(new Msg(false, s(m, "text")));
				if (!from.equals(viewing)) unread.merge(from, 1, Integer::sum);
			}
			case "sess" -> hostSession(m.get("id").getAsInt());
			case "joined" -> joinSession(m.get("id").getAsInt());
			case "close" -> closeSock(m.get("id").getAsInt(), false);
			default -> {
			}
		}
		version.incrementAndGet();
	}

	// ---- outgoing ----

	private static JsonObject o(String t, Object... kv) {
		JsonObject j = new JsonObject();
		j.addProperty("t", t);
		for (int i = 0; i < kv.length; i += 2) {
			String k = (String) kv[i];
			Object v = kv[i + 1];
			if (v instanceof Number n) j.addProperty(k, n);
			else if (v instanceof Boolean b) j.addProperty(k, b);
			else j.addProperty(k, String.valueOf(v));
		}
		return j;
	}

	/** java.net.http.WebSocket allows one send at a time, so sends are chained. */
	private synchronized void out(Function<WebSocket, CompletableFuture<WebSocket>> f) {
		WebSocket w = ws;
		if (w == null) return;
		chain = chain.handle((a, b) -> (Void) null).thenCompose(x -> f.apply(w).handle((a, b) -> (Void) null));
	}

	private void send(JsonObject j) {
		out(w -> w.sendText(j.toString(), true));
	}

	private static boolean has(List<String> l, String n) {
		return l.stream().anyMatch(x -> x.equalsIgnoreCase(n));
	}

	private JsonArray friendsJson() {
		JsonArray a = new JsonArray();
		Config.I.friends.forEach(a::add);
		return a;
	}

	private List<Friend> offlineFriends() {
		return Config.I.friends.stream().map(n -> new Friend(n, "offline")).toList();
	}

	/** Friends list changed locally: save it, tell the server, and refresh the view if offline. */
	private void listChanged() {
		Config.save();
		send(withList(o("list")));
		if (!connected) friends = offlineFriends();
		version.incrementAndGet();
	}

	private JsonObject withList(JsonObject j) {
		j.add("friends", friendsJson());
		return j;
	}

	/** Adding someone, or accepting their request, is the same thing: list them. They become a friend once they list me too. */
	public void add(String name) {
		name = name.trim();
		if (!name.matches("[A-Za-z0-9_]{3,16}")) {
			info = "That is not a valid Minecraft username";
		} else if (name.equalsIgnoreCase(Minecraft.getInstance().getUser().getName())) {
			info = "You can't add yourself";
		} else if (has(Config.I.friends, name)) {
			info = "Already on your list";
		} else {
			String n = name;
			Config.I.ignored.removeIf(x -> x.equalsIgnoreCase(n));
			Config.I.friends.add(n);
			info = "Added " + n + ". They become your friend when they accept (both of you online once).";
			listChanged();
			return;
		}
		version.incrementAndGet();
	}

	public void accept(String name) {
		add(name);
	}

	public void decline(String name) {
		Config.I.ignored.add(name);
		Config.save();
		requests = requests.stream().filter(x -> !x.equalsIgnoreCase(name)).toList();
		version.incrementAndGet();
	}

	public void remove(String name) {
		Config.I.friends.removeIf(x -> x.equalsIgnoreCase(name));
		Config.I.ignored.add(name);
		chats.remove(name);
		listChanged();
	}

	public void hide(boolean on) {
		send(o("hide", "on", on));
	}

	public void sendMsg(String to, String text) {
		send(o("msg", "name", to, "text", text));
		chats.computeIfAbsent(to, k -> new CopyOnWriteArrayList<>()).add(new Msg(true, text));
		version.incrementAndGet();
	}

	public void hostOpen(int port) {
		hostPort = port;
		send(o("host", "on", true));
		version.incrementAndGet();
	}

	public void hostClose() {
		hostPort = -1;
		send(o("host", "on", false));
		version.incrementAndGet();
	}

	public void join(String friend) {
		send(o("join", "name", friend));
	}

	// ---- world tunnel (TCP <-> websocket frames: 4-byte session id + payload) ----

	/** Host side: a friend wants in, so open a socket to my LAN world. */
	private void hostSession(int id) {
		Thread t = new Thread(() -> {
			try {
				Socket s = new Socket("127.0.0.1", hostPort);
				attach(id, s);
			} catch (IOException e) {
				send(o("close", "id", id));
			}
		}, "friendsmod-host");
		t.setDaemon(true);
		t.start();
	}

	/** Joiner side: listen on localhost, point Minecraft at it, tunnel whatever it sends. */
	private void joinSession(int id) {
		Thread t = new Thread(() -> {
			try (ServerSocket ss = new ServerSocket(0, 1, InetAddress.getLoopbackAddress())) {
				ss.setSoTimeout(30000);
				Minecraft mc = Minecraft.getInstance();
				mc.execute(() -> Ui.connect(ss.getLocalPort()));
				attach(id, ss.accept());
			} catch (IOException e) {
				send(o("close", "id", id));
			}
		}, "friendsmod-join");
		t.setDaemon(true);
		t.start();
	}

	private void attach(int id, Socket s) throws IOException {
		s.setTcpNoDelay(true);
		socks.put(id, s);
		Thread t = new Thread(() -> {
			try (InputStream in = s.getInputStream()) {
				byte[] buf = new byte[16384];
				int n;
				while ((n = in.read(buf)) > 0) {
					ByteBuffer b = ByteBuffer.allocate(n + 4);
					b.putInt(id).put(buf, 0, n).flip();
					out(w -> w.sendBinary(b, true));
				}
			} catch (IOException ignored) {
			}
			closeSock(id, true);
		}, "friendsmod-pipe");
		t.setDaemon(true);
		t.start();
	}

	private void closeSock(int id, boolean notify) {
		Socket s = socks.remove(id);
		if (s == null) return;
		try {
			s.close();
		} catch (IOException ignored) {
		}
		if (notify) send(o("close", "id", id));
	}

	private void fromNet(byte[] f) {
		if (f.length < 5) return;
		int id = ByteBuffer.wrap(f).getInt();
		Socket s = socks.get(id);
		if (s == null) return;
		try {
			s.getOutputStream().write(f, 4, f.length - 4);
		} catch (IOException e) {
			closeSock(id, true);
		}
	}
}
