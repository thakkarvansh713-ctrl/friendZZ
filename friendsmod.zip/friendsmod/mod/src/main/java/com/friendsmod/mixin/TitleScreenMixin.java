package com.friendsmod.mixin;

import com.friendsmod.FriendsScreen;
import com.friendsmod.Ui;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.gui.screens.TitleScreen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

@Mixin(TitleScreen.class)
public abstract class TitleScreenMixin extends Screen {
	protected TitleScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "init", at = @At("RETURN"))
	private void friendsmod$addButton(CallbackInfo ci) {
		this.addRenderableWidget(Button.builder(Component.literal("Friends"), b -> Ui.open(new FriendsScreen(this)))
			.bounds(6, 6, 70, 20).build());
	}
}
