package com.friendsmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.screens.ConnectScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.multiplayer.ServerData;
import net.minecraft.client.multiplayer.resolver.ServerAddress;

import java.util.ArrayList;
import java.util.List;

/**
 * Every Minecraft call that has changed between versions lives here, so if 26.2 renamed something
 * the fix is one line in this file.
 */
public final class Ui {
	public record Theme(int bg, int side, int panel, int chat, int text, int sub, int accent, int online, int hosting, int offline) {}

	private static final Theme DARK = new Theme(0xFF080B12, 0xFF10192B, 0xFF182238, 0xFF0E1526,
		0xFFE6EAF2, 0xFF8B95A7, 0xFF3B82F6, 0xFF3FB950, 0xFFE3B341, 0xFF5B6372);
	private static final Theme LIGHT = new Theme(0xFFE9EDF4, 0xFFD6DDEA, 0xFFFFFFFF, 0xFFF1F4F9,
		0xFF16203A, 0xFF5B6678, 0xFF2563EB, 0xFF1F9D3A, 0xFFB7791F, 0xFF9AA3B2);

	public static Theme theme() {
		return Config.I.dark ? DARK : LIGHT;
	}

	public static void open(Screen s) {
		Minecraft.getInstance().gui.setScreen(s); // 26.1.2 and older: Minecraft.getInstance().setScreen(s)
	}

	public static void fill(GuiGraphicsExtractor g, int x1, int y1, int x2, int y2, int argb) {
		g.fill(x1, y1, x2, y2, argb);
	}

	public static void text(GuiGraphicsExtractor g, String s, int x, int y, int argb) {
		g.text(Minecraft.getInstance().font, s, x, y, argb, false);
	}

	/** Connects to the local end of the relay tunnel, which leads to the friend's world. */
	public static void connect(int port) {
		Minecraft mc = Minecraft.getInstance();
		String ip = "127.0.0.1:" + port;
		ConnectScreen.startConnecting(mc.gui.screen(), mc, // 26.2 moved Minecraft#screen to Gui#screen() ServerAddress.parseString(ip),
			new ServerData("Friend's world", ip, ServerData.Type.OTHER), false, null);
	}

	/** Word-wrap using the real font width. */
	public static List<String> wrap(String s, int maxWidth) {
		var font = Minecraft.getInstance().font;
		List<String> out = new ArrayList<>();
		StringBuilder line = new StringBuilder();
		for (String word : s.split(" ", -1)) {
			String t = line.isEmpty() ? word : line + " " + word;
			if (font.width(t) <= maxWidth) {
				line = new StringBuilder(t);
				continue;
			}
			if (!line.isEmpty()) out.add(line.toString());
			line = new StringBuilder();
			for (char c : word.toCharArray()) { // a single word wider than the box
				if (font.width(line.toString() + c) > maxWidth && !line.isEmpty()) {
					out.add(line.toString());
					line = new StringBuilder();
				}
				line.append(c);
			}
		}
		out.add(line.toString());
		return out;
	}
}
