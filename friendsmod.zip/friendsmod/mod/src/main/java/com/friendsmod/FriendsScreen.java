package com.friendsmod;

import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.server.IntegratedServer;
import net.minecraft.network.chat.Component;
import net.minecraft.util.HttpUtil;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

/** Sidebar (search, requests, friends, add button) on the left, chat / add-friend panel on the right. */
public class FriendsScreen extends Screen {
	private static final int SW = 160; // sidebar width
	private static final int ROW = 22;

	private final Screen parent;
	private final Net net = Net.I;

	private String search = "", draft = "", addText = "", selected;
	private boolean adding, dirty, focusSearch, focusInput, focusAdd;
	private int scroll, seen = -1;
	private EditBox searchBox, input, addBox;

	// what init() decided to paint; drawn by the two renderables below
	private final List<Object[]> labels = new ArrayList<>(); // {x, y, text, color}
	private final List<int[]> dots = new ArrayList<>();      // {x, y, color}
	private int[] chatRect;                                  // {x1, y1, x2, y2} or null

	public FriendsScreen(Screen parent) {
		super(Component.literal("Friends"));
		this.parent = parent;
	}

	private int statusColor(String status) {
		Ui.Theme t = Ui.theme();
		return status.equals("online") ? t.online() : status.equals("hosting") ? t.hosting() : t.offline();
	}

	@Override
	protected void init() {
		labels.clear();
		dots.clear();
		chatRect = null;
		Ui.Theme t = Ui.theme();
		Minecraft mc = Minecraft.getInstance();
		int sx = 10, mx = sx + SW + 8, mr = width - 10;

		net.viewing = adding ? null : selected;
		if (selected != null) net.unread.remove(selected);

		addRenderableOnly((g, a, b, c) -> paintBack(g));

		// ---- sidebar ----
		searchBox = new EditBox(font, sx + 4, 12, SW - 8, 18, Component.literal("Search"));
		searchBox.setHint(Component.literal("Search friends..."));
		searchBox.setValue(search);
		searchBox.setResponder(s -> { // set after setValue so it doesn't fire during init
			search = s;
			scroll = 0;
			dirty = true;
		});
		addRenderableWidget(searchBox);

		List<String[]> rows = new ArrayList<>(); // {kind, name, status}
		String q = search.toLowerCase();
		for (String r : net.requests) if (r.toLowerCase().contains(q)) rows.add(new String[]{"req", r, ""});
		List<Net.Friend> fl = new ArrayList<>(net.friends);
		fl.sort(Comparator.comparing((Net.Friend f) -> f.status().equals("hosting") ? 0 : f.status().equals("online") ? 1 : 2).thenComparing(f -> f.name().toLowerCase()));
		for (Net.Friend f : fl) if (f.name().toLowerCase().contains(q)) rows.add(new String[]{"fr", f.name(), f.status()});

		int top = 38;
		int cap = Math.max(1, (height - top - 64) / ROW);
		scroll = Math.max(0, Math.min(scroll, Math.max(0, rows.size() - cap)));
		for (int i = scroll; i < Math.min(rows.size(), scroll + cap); i++) {
			String[] r = rows.get(i);
			String n = r[1];
			int y = top + (i - scroll) * ROW;
			if (r[0].equals("req")) {
				labels.add(new Object[]{sx + 8, y + 6, "+ " + n, t.accent()});
				int bx2 = sx + SW - 4 - 22, bx1 = bx2 - 24;
				addRenderableWidget(Button.builder(Component.literal("OK"), b -> net.accept(n)).bounds(bx1, y, 22, 20).build());
				addRenderableWidget(Button.builder(Component.literal("X"), b -> net.decline(n)).bounds(bx2, y, 22, 20).build());
			} else {
				int u = net.unread.getOrDefault(n, 0);
				String label = (n.equals(selected) && !adding ? "> " : "") + n + (u > 0 ? " (" + u + ")" : "");
				addRenderableWidget(Button.builder(Component.literal(label), b -> {
					selected = n;
					adding = false;
					draft = "";
					focusInput = true;
					dirty = true;
				}).bounds(sx + 4, y, SW - 8, 20).build());
				dots.add(new int[]{sx + 10, y + 7, statusColor(r[2])});
			}
		}
		if (rows.size() > cap) {
			int half = (SW - 12) / 2;
			addRenderableWidget(Button.builder(Component.literal("^"), b -> { scroll = Math.max(0, scroll - 1); dirty = true; })
				.bounds(sx + 4, height - 58, half, 20).build());
			addRenderableWidget(Button.builder(Component.literal("v"), b -> { scroll++; dirty = true; })
				.bounds(sx + 8 + half, height - 58, half, 20).build());
		}
		addRenderableWidget(Button.builder(Component.literal("+ Add Friend"), b -> {
			adding = true;
			selected = null;
			net.info = "";
			focusAdd = true;
			dirty = true;
		}).bounds(sx + 4, height - 32, SW - 8, 20).build());

		// ---- top bar ----
		labels.add(new Object[]{mx + 12, 14, "Friends", t.text()});
		String conn = net.connected ? "Connected" : net.info.isEmpty() ? "Connecting..." : net.info;
		labels.add(new Object[]{mx + 62, 14, conn, net.connected ? t.online() : t.sub()});
		int settingsX = mr - 70, backX = settingsX - 54;
		addRenderableWidget(Button.builder(Component.literal("Settings"), b -> Ui.open(new SettingsScreen(this)))
			.bounds(settingsX, 8, 62, 20).build());
		addRenderableWidget(Button.builder(Component.literal("Back"), b -> onClose()).bounds(backX, 8, 46, 20).build());

		IntegratedServer srv = mc.getSingleplayerServer();
		if (srv != null) {
			if (net.hostPort > 0) {
				labels.add(new Object[]{backX - 150, 14, "Your world is open to friends", t.hosting()});
			} else {
				addRenderableWidget(Button.builder(Component.literal("Open world to friends"), b -> openWorld())
					.bounds(backX - 142, 8, 138, 20).build());
			}
		}

		// ---- main panel ----
		if (adding) {
			int fw = Math.min(220, mr - mx - 24);
			labels.add(new Object[]{mx + 12, 48, "Add a friend", t.text()});
			labels.add(new Object[]{mx + 12, 62, "Their Minecraft username (they need the mod and to have opened it once):", t.sub()});
			addBox = new EditBox(font, mx + 12, 80, fw, 20, Component.literal("Username"));
			addBox.setMaxLength(16);
			addBox.setValue(addText);
			addBox.setResponder(s -> addText = s);
			addRenderableWidget(addBox);
			addRenderableWidget(Button.builder(Component.literal("Send request"), b -> {
				if (!addText.isBlank()) net.add(addText.trim());
			}).bounds(mx + 12, 106, 110, 20).build());
			if (!net.info.isEmpty() && net.connected) labels.add(new Object[]{mx + 12, 134, net.info, t.accent()});
		} else if (selected != null) {
			Net.Friend f = net.friends.stream().filter(x -> x.name().equals(selected)).findFirst().orElse(null);
			if (f == null) {
				selected = null;
				dirty = true;
			} else {
				buildChat(f, mx, mr, mc);
			}
		} else {
			labels.add(new Object[]{mx + 12, 48, net.friends.isEmpty() ? "No friends yet." : "Pick a friend on the left to chat.", t.text()});
			labels.add(new Object[]{mx + 12, 62, "Press + Add Friend to send a request.", t.sub()});
			labels.add(new Object[]{mx + 12, 80, "Friends can join your singleplayer world: open it from the pause menu's Friends button.", t.sub()});
		}

		// focus after a rebuild
		if (focusSearch) setInitialFocus(searchBox);
		else if (focusAdd && addBox != null && adding) setInitialFocus(addBox);
		else if (focusInput && input != null && !adding) setInitialFocus(input);
		focusSearch = focusInput = focusAdd = false;

		addRenderableOnly((g, a, b, c) -> paintFront(g));
	}

	private void buildChat(Net.Friend f, int mx, int mr, Minecraft mc) {
		Ui.Theme t = Ui.theme();
		String n = f.name();
		boolean hosting = f.status().equals("hosting");
		labels.add(new Object[]{mx + 12, 44, n, t.text()});
		boolean pending = f.status().equals("pending");
		String st = pending ? "Waiting for them to add you back" : hosting ? (mc.level == null ? "Hosting a world" : "Hosting a world (leave your world to join)")
			: f.status().equals("online") ? "Online" : "Offline";
		labels.add(new Object[]{mx + 12, 56, st, statusColor(f.status())});

		int bx = mr - 8 - 60;
		addRenderableWidget(Button.builder(Component.literal("Unfriend"), b -> {
			net.remove(n);
			selected = null;
			dirty = true;
		}).bounds(bx, 40, 60, 20).build());
		if (hosting) {
			bx -= 54;
			Button join = Button.builder(Component.literal("Join"), b -> net.join(n)).bounds(bx, 40, 50, 20).build();
			join.active = mc.level == null;
			addRenderableWidget(join);
		}
		if (net.hostPort > 0 && !f.status().equals("offline")) {
			bx -= 64;
			addRenderableWidget(Button.builder(Component.literal("Invite"), b ->
				net.sendMsg(n, "Join my world! Open Friends and press Join.")).bounds(bx, 40, 60, 20).build());
		}

		int x1 = mx + 8, y1 = 68, x2 = mr - 8, y2 = height - 40;
		chatRect = new int[]{x1, y1, x2, y2};
		int lh = font.lineHeight + 3, capLines = Math.max(1, (y2 - y1 - 8) / lh);
		List<Object[]> lines = new ArrayList<>();
		for (Net.Msg m : net.chats.getOrDefault(n, List.of())) {
			for (String l : Ui.wrap((m.mine() ? "You" : n) + ": " + m.text(), x2 - x1 - 16)) {
				lines.add(new Object[]{l, m.mine() ? t.accent() : t.text()});
			}
		}
		int start = Math.max(0, lines.size() - capLines);
		for (int i = start; i < lines.size(); i++) {
			labels.add(new Object[]{x1 + 8, y1 + 6 + (i - start) * lh, lines.get(i)[0], lines.get(i)[1]});
		}

		if (pending) return;
		input = new EditBox(font, x1, height - 32, x2 - x1 - 56, 20, Component.literal("Message"));
		input.setMaxLength(300);
		input.setHint(Component.literal("Message " + n + "..."));
		input.setValue(draft);
		input.setResponder(s -> draft = s);
		addRenderableWidget(input);
		addRenderableWidget(Button.builder(Component.literal("Send"), b -> {
			String s = draft.trim();
			if (s.isEmpty()) return;
			draft = "";
			net.sendMsg(n, s);
			focusInput = true;
		}).bounds(x2 - 52, height - 32, 52, 20).build());
	}

	private void openWorld() {
		IntegratedServer s = Minecraft.getInstance().getSingleplayerServer();
		if (s == null) return;
		int port = s.isPublished() ? s.getPort() : HttpUtil.getAvailablePort();
		if (s.isPublished() || s.publishServer(s.getDefaultGameType(), false, port)) net.hostOpen(port);
		dirty = true;
	}

	private void paintBack(GuiGraphicsExtractor g) {
		Ui.Theme t = Ui.theme();
		int mx = 10 + SW + 8;
		Ui.fill(g, 0, 0, width, height, t.bg());
		Ui.fill(g, 10, 6, 10 + SW, height - 6, t.side());
		Ui.fill(g, mx, 6, width - 10, height - 6, t.panel());
		Ui.fill(g, mx, 6, width - 10, 8, t.accent());
		if (chatRect != null) Ui.fill(g, chatRect[0], chatRect[1], chatRect[2], chatRect[3], t.chat());
	}

	private void paintFront(GuiGraphicsExtractor g) {
		for (int[] d : dots) Ui.fill(g, d[0], d[1], d[0] + 6, d[1] + 6, d[2]);
		for (Object[] l : labels) Ui.text(g, (String) l[2], (int) l[0], (int) l[1], (int) l[3]);
	}

	@Override
	public void tick() {
		if (dirty || seen != net.version.get()) {
			focusSearch |= searchBox != null && searchBox.isFocused();
			focusInput |= input != null && input.isFocused();
			focusAdd |= addBox != null && addBox.isFocused();
			seen = net.version.get();
			dirty = false;
			rebuildWidgets();
		}
	}

	@Override
	public void removed() {
		net.viewing = null;
	}

	@Override
	public void onClose() {
		Ui.open(parent);
	}
}
