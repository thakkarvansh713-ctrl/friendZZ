package com.friendsmod;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import net.fabricmc.loader.api.FabricLoader;

import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Properties;
import java.util.UUID;

/** Saved to .minecraft/config/friendsmod.json. Your friend list lives here, the server keeps nothing. */
public final class Config {
	public String server = defaultServer();
	public String token = UUID.randomUUID().toString() + UUID.randomUUID();
	public boolean dark = true;
	public boolean appearOffline = false;
	public List<String> friends = new ArrayList<>();  // people I added (a friend once they add me back)
	public List<String> ignored = new ArrayList<>();  // declined / removed, hidden from my requests

	public static Config I;
	private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();

	/** Set once in gradle.properties (default_server) and baked into the jar. */
	private static String defaultServer() {
		try (var in = Config.class.getResourceAsStream("/friendsmod.properties")) {
			Properties p = new Properties();
			p.load(in);
			return p.getProperty("server");
		} catch (Exception e) {
			return "ws://localhost:8080";
		}
	}

	private static Path file() {
		return FabricLoader.getInstance().getConfigDir().resolve("friendsmod.json");
	}

	public static void load() {
		try {
			I = GSON.fromJson(Files.readString(file()), Config.class);
		} catch (Exception ignored) {
		}
		if (I == null) I = new Config();
		save();
	}

	public static void save() {
		try {
			Files.writeString(file(), GSON.toJson(I));
		} catch (Exception ignored) {
		}
	}
}
