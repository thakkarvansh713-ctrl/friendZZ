package com.friendsmod.mixin;

import com.friendsmod.FriendsScreen;
import com.friendsmod.Ui;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.PauseScreen;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfo;

/** Same button in the pause menu, so you can message friends and open your world while playing. */
@Mixin(PauseScreen.class)
public abstract class PauseScreenMixin extends Screen {
	protected PauseScreenMixin(Component title) {
		super(title);
	}

	@Inject(method = "init", at = @At("RETURN"))
	private void friendsmod$addButton(CallbackInfo ci) {
		this.addRenderableWidget(Button.builder(Component.literal("Friends"), b -> Ui.open(new FriendsScreen(this)))
			.bounds(6, 6, 70, 20).build());
	}
}
