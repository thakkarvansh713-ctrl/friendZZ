package com.friendsmod;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;

public class FriendsMod implements ClientModInitializer {
	@Override
	public void onInitializeClient() {
		Config.load();
		Net.I = new Net();
		Net.I.start();
		// When the singleplayer world closes, stop advertising it to friends.
		ClientTickEvents.END_CLIENT_TICK.register(mc -> {
			if (Net.I.hostPort > 0 && mc.getSingleplayerServer() == null) Net.I.hostClose();
		});
	}
}
