package com.friendsmod;

import net.minecraft.client.gui.GuiGraphicsExtractor;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.components.EditBox;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class SettingsScreen extends Screen {
	private final Screen parent;
	private String url = Config.I.server;
	private EditBox urlBox;

	public SettingsScreen(Screen parent) {
		super(Component.literal("Friends settings"));
		this.parent = parent;
	}

	@Override
	protected void init() {
		int w = 240, x = (width - w) / 2, y = 56;
		addRenderableOnly((g, a, b, c) -> paint(g, x - 14, w + 28));

		addRenderableWidget(Button.builder(Component.literal("Theme: " + (Config.I.dark ? "Dark" : "Light")), b -> {
			Config.I.dark = !Config.I.dark;
			Config.save();
			rebuildWidgets();
		}).bounds(x, y, w, 20).build());

		addRenderableWidget(Button.builder(Component.literal("Appear offline: " + (Config.I.appearOffline ? "On" : "Off")), b -> {
			Config.I.appearOffline = !Config.I.appearOffline;
			Config.save();
			Net.I.hide(Config.I.appearOffline);
			rebuildWidgets();
		}).bounds(x, y + 26, w, 20).build());

		urlBox = new EditBox(font, x, y + 70, w, 20, Component.literal("Server"));
		urlBox.setMaxLength(200);
		urlBox.setValue(url);
		urlBox.setResponder(s -> url = s);
		addRenderableWidget(urlBox);
		addRenderableWidget(Button.builder(Component.literal("Save server & reconnect"), b -> {
			Config.I.server = url.trim();
			Config.save();
			Net.I.reconnect();
		}).bounds(x, y + 94, w, 20).build());

		addRenderableWidget(Button.builder(Component.literal("Clear chat history"), b -> {
			Net.I.chats.clear();
			Net.I.unread.clear();
			Net.I.version.incrementAndGet();
		}).bounds(x, y + 126, w, 20).build());

		addRenderableWidget(Button.builder(Component.literal("Done"), b -> onClose()).bounds(x, y + 158, w, 20).build());
	}

	private void paint(GuiGraphicsExtractor g, int px, int pw) {
		Ui.Theme t = Ui.theme();
		Ui.fill(g, 0, 0, width, height, t.bg());
		Ui.fill(g, px, 12, px + pw, 56 + 190, t.panel());
		Ui.fill(g, px, 12, px + pw, 14, t.accent());
		Ui.text(g, "Settings", px + 14, 24, t.text());
		Ui.text(g, "Server address (ws:// or wss://)", px + 14, 56 + 58, t.sub());
	}

	@Override
	public void onClose() {
		Ui.open(parent);
	}
}
