# Friends mod (Minecraft 26.2, Fabric)

Friends button on the main menu and pause menu -> dark/light friends GUI with search, add friend,
online status, messages, and joining a friend's singleplayer world.

`mod/` is the Fabric mod. `server/` is a tiny server all players connect to (it only shows who is
online, passes messages and relays world connections; it stores nothing, so any free host works).

## Setup (once)
1. **Server:** put this whole folder on GitHub (new repo, upload or `git push` from your Codespace).
   On render.com: New -> Blueprint -> pick the repo -> Apply. Copy the URL it gives you,
   e.g. `https://friendsmod-server-abcd.onrender.com`.
2. **Mod:** open `mod/gradle.properties`, set `default_server=wss://friendsmod-server-abcd.onrender.com`
   (same address, `wss://` instead of `https://`).
3. **Build** in your Codespace: `cd mod && ./gradlew build --no-daemon`
   -> `mod/build/libs/friendsmod-1.0.0.jar`. Gradle wrapper is included, nothing to copy.
4. Send that jar to your friends. They drop it in `mods` with Fabric API. No setup on their side.

## Using it
- Friends -> **+ Add Friend** -> type their Minecraft name. They get it in their sidebar and press OK.
  You are friends when both of you added each other (both online once for that to show up).
- Host: open your singleplayer world, pause -> Friends -> **Open world to friends**.
- Friend: Friends -> click you -> **Join** (from the main menu). **Invite** sends them a message.
- It's a normal LAN world, so vanilla PvP (axe shield stun) works.

## Notes
- Render's free plan puts the server to sleep when nobody is connected; the first connection after
  that can take about a minute (the mod keeps retrying by itself).
- If the build shows a compile error (26.2 names), it is one line in `Ui.java` or `FriendsScreen.openWorld()`.
- Minecraft 26.2 has its own Friends button too; if it overlaps ours, move ours in the two mixins.
