// FriendsMod server. Stateless on purpose: every client keeps its own friend list and sends it when it
// connects, so this runs on any free host (no database, no disk) and a restart loses nothing important.
// Two people are friends when each one lists the other. Also relays world connections between friends.
// shortcut: name ownership lives in memory (after a restart the first client to reconnect keeps a name),
// and state is pushed to everyone on each change, fine for a friend group, upgrade if it gets big.
const http = require('http');
const { WebSocketServer } = require('ws');

const PORT = process.env.PORT || 8080;
const NAME = /^[A-Za-z0-9_]{3,16}$/;

const conns = new Map();   // key -> { key, name, ws, hidden, hosting, list:Map(key->name) }
const owners = new Map();  // key -> token
const boxes = new Map();   // target key -> [{ fromKey, from, text }] messages waiting for an offline friend
const sessions = new Map(); // id -> { host, joiner } (ws objects)
let nextId = 1;

const send = (ws, o) => ws && ws.readyState === 1 && ws.send(JSON.stringify(o));
const key = n => String(n).toLowerCase();
const isMutual = (a, b) => a.list.has(b.key) && b.list.has(a.key);

function statusFor(u, k) {
  const c = conns.get(k);
  if (!c || c.hidden) return 'offline';
  if (!c.list.has(u.key)) return 'pending'; // I listed them, they haven't listed me yet
  return c.hosting ? 'hosting' : 'online';
}

function pushState(u) {
  send(u.ws, {
    t: 'state',
    friends: [...u.list].map(([k, name]) => ({ name: conns.has(k) ? conns.get(k).name : name, status: statusFor(u, k) })),
    // people who listed me but I haven't listed back
    requests: [...conns.values()].filter(x => x !== u && !x.hidden && x.list.has(u.key) && !u.list.has(x.key)).map(x => x.name),
  });
}
const pushAll = () => conns.forEach(pushState);

function dropSessions(ws) {
  for (const [id, s] of sessions) {
    if (s.host === ws || s.joiner === ws) {
      send(s.host === ws ? s.joiner : s.host, { t: 'close', id });
      sessions.delete(id);
    }
  }
}

function parseList(arr) {
  const out = new Map();
  if (Array.isArray(arr)) for (const n of arr.slice(0, 200)) if (typeof n === 'string' && NAME.test(n)) out.set(key(n), n);
  return out;
}

// plain HTTP answer so hosting platforms' health checks pass
const server = http.createServer((req, res) => { res.end('FriendsMod server OK'); });
const wss = new WebSocketServer({ server, maxPayload: 1 << 20 });

wss.on('connection', ws => {
  let me = null;
  ws.alive = true;
  ws.on('pong', () => (ws.alive = true));

  ws.on('message', (data, isBinary) => {
    if (isBinary) {
      if (!me || data.length < 5) return;
      const s = sessions.get(data.readUInt32BE(0));
      if (!s) return;
      const to = ws === s.host ? s.joiner : ws === s.joiner ? s.host : null;
      if (to && to.readyState === 1) to.send(data, { binary: true });
      return;
    }
    let m;
    try { m = JSON.parse(data.toString()); } catch { return; }

    if (m.t === 'auth') {
      if (me) return;
      if (!NAME.test(m.name || '') || typeof m.token !== 'string' || m.token.length < 16) {
        send(ws, { t: 'err', text: 'Invalid name or token' });
        return ws.close();
      }
      const k = key(m.name);
      if (owners.has(k) && owners.get(k) !== m.token) {
        send(ws, { t: 'err', text: 'That name is already in use by another install' });
        return ws.close();
      }
      owners.set(k, m.token);
      const old = conns.get(k);
      if (old) old.ws.close();
      me = { key: k, name: m.name, ws, hidden: !!m.hidden, hosting: false, list: parseList(m.friends) };
      conns.set(k, me);
      send(ws, { t: 'ok' });
      for (const x of boxes.get(k) || []) if (me.list.has(x.fromKey)) send(ws, { t: 'msg', from: x.from, text: x.text });
      boxes.delete(k);
      return pushAll();
    }
    if (!me || conns.get(me.key) !== me) return;
    const tk = m.name !== undefined ? key(m.name) : null;

    switch (m.t) {
      case 'list':
        me.list = parseList(m.friends);
        return pushAll();
      case 'hide':
        me.hidden = !!m.on;
        return pushAll();
      case 'host':
        me.hosting = !!m.on;
        if (!me.hosting) dropSessions(ws);
        return pushAll();
      case 'msg': {
        const text = String(m.text || '').trim().slice(0, 500);
        if (!text || !me.list.has(tk)) return;
        const tc = conns.get(tk);
        if (tc) {
          if (!tc.list.has(me.key)) return send(ws, { t: 'info', text: 'They have not accepted you yet' });
          return send(tc.ws, { t: 'msg', from: me.name, text });
        }
        const box = boxes.get(tk) || [];
        box.push({ fromKey: me.key, from: me.name, text });
        boxes.set(tk, box.slice(-100));
        return;
      }
      case 'join': {
        const hc = conns.get(tk);
        if (!hc || !hc.hosting || !isMutual(me, hc)) return send(ws, { t: 'info', text: 'That friend is not hosting' });
        const id = nextId++;
        sessions.set(id, { host: hc.ws, joiner: ws });
        send(hc.ws, { t: 'sess', id });
        return send(ws, { t: 'joined', id });
      }
      case 'close': {
        const s = sessions.get(m.id);
        if (!s || (s.host !== ws && s.joiner !== ws)) return;
        send(s.host === ws ? s.joiner : s.host, { t: 'close', id: m.id });
        sessions.delete(m.id);
      }
    }
  });

  ws.on('close', () => {
    dropSessions(ws);
    if (me && conns.get(me.key) === me) {
      conns.delete(me.key);
      pushAll();
    }
  });
  ws.on('error', () => {});
});

// keep proxies (Render, Railway...) from dropping idle sockets
setInterval(() => {
  wss.clients.forEach(ws => {
    if (!ws.alive) return ws.terminate();
    ws.alive = false;
    ws.ping();
  });
}, 25000);

server.listen(PORT, () => console.log('FriendsMod server listening on :' + PORT));
